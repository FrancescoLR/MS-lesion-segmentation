#!/usr/bin/env bash

export niftynet_wheel=$(ls $niftynet_dir/dist/*.whl)  # there will be only one file!

