## Writing unit tests
Please checkout [niftynet.readthedocs.io](http://niftynet.readthedocs.io/en/dev/contributing.html#writing-unit-tests).
