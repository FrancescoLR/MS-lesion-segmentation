#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

from niftynet import main

if __name__ == "__main__":
    sys.exit(main())
