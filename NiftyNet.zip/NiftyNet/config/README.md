# Configuration file
*[This folder](../config) presents a few examples of configuration files for NiftyNet
[applications](#../niftynet/application/).*

Please check out the configuration specifications at

[http://niftynet.readthedocs.io/en/dev/config_spec.html](http://niftynet.readthedocs.io/en/dev/config_spec.html)
