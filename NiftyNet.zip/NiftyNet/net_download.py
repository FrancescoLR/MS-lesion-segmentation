#!/usr/bin/env python
#  -*- coding: utf-8 -*-
import sys

from niftynet.utilities.download import main

if __name__ == "__main__":
    sys.exit(main())
