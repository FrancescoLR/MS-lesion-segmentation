"""

.. module:: niftynet.network
   :synopsis: Neural network (re-)implementations.

"""
