"""

.. module:: niftynet.contrib
   :synopsis: Experimental code for new features.

"""
