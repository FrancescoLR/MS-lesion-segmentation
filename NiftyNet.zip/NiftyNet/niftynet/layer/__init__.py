"""

.. module:: niftynet.layer
   :synopsis: Building blocks for neural network layers.

"""
