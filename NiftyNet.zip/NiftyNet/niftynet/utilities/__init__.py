"""

.. module:: niftynet.utilities
   :synopsis: High-level re-usable utilities.

"""


from .niftynet_launch_config import NiftyNetLaunchConfig
