"""

.. module:: niftynet.evaluation
   :synopsis: Evaluation metrics for network outputs.

"""
