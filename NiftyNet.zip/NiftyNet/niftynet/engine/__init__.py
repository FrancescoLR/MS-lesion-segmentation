# -*- coding: utf-8 -*-

"""

.. module:: niftynet.engine
   :synopsis: Application engine.

"""
