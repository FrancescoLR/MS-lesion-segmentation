"""

.. module:: niftynet.application
   :synopsis: Specific high-level NiftyNet applications.

"""
