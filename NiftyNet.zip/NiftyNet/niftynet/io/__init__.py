"""

.. module:: niftynet.io
   :synopsis: High-level input / output operations.

"""
