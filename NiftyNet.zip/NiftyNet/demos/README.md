* Please checkout [NiftyNet model zoo](https://github.com/NifTK/NiftyNetModelZoo/blob/master/README.md) for demos and trained models.

* Please checkout [NiftyNet documentation website](http://niftynet.readthedocs.io/en/dev/config_spec.html) for configuration file usage.

