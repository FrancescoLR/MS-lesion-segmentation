_Please checkout a trained model in [NiftyNet model zoo](https://github.com/NifTK/NiftyNetModelZoo/blob/master/ultrasound_simulator_gan_model_zoo.md)._

