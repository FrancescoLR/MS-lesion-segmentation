This folder presents the IPython notebook document and scripts for tutorial:

  > Zach Eaton-Rosen, "[Using NiftyNet to Train U-Net for Cell Segmentation](http://www.miccai.org/edu/finalists/U-Net_Demo.html)", 2018.

The tutorial is the winner<sup>*</sup> 
of [the MICCAI educational challenge 2018](http://www.miccai.org/edu/mec.html).

<sup>*Decided through expert panel judging followed by a popular vote.</sup>
