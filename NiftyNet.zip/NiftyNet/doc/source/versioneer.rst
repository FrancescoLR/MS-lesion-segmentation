versioneer module
=================

.. automodule:: versioneer
    :members:
    :undoc-members:
    :show-inheritance:
