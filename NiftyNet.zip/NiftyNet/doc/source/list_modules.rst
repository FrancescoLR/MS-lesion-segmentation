niftynet
--------

.. toctree::
    :maxdepth: 1

    niftynet.application
    niftynet.contrib
    niftynet.engine
    niftynet.evaluation
    niftynet.io
    niftynet.layer
    niftynet.network
    niftynet.utilities
