# Extending application

Please checkout [the slides](https://docs.google.com/presentation/d/1pjGUYTXpi-onbVe90pVtk2xKmBH_J9VYqkmJdXee1Dk/edit?usp=sharing) for an overview.

<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vSrPbb-Z6rAPeIy9YgDINR5yOgFJEcAbYFdwtZcsmePWWLa-a9IEnWJISx-UhVKAf-pF-Tka9oGdRbR/embed?start=false&loop=true&delayms=10000" frameborder="0" width="480" height="299" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
