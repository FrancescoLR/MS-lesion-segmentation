# Platform overview

Please checkout the talk at "Medical Imaging meets NIPS", NIPS 2017 by M. Jorge Cardoso:

['NiftyNet: An open-source community-driven framework for neural networks in medical imaging'](https://www.youtube.com/watch?v=ZaWStjGf0wg)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/ZaWStjGf0wg?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
